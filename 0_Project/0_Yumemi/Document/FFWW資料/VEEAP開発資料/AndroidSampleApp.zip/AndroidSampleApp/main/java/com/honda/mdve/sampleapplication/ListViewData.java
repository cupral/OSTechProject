package com.honda.mdve.sampleapplication;

public class ListViewData {
    private String mListText;
    private String mNo;

    public void setListText(String text) {
        mListText = text;
    }

    public void setNo(String No) { mNo = No;}

    public String getListText() {
        return mListText;
    }

    public String getNo() { return mNo; }
}
