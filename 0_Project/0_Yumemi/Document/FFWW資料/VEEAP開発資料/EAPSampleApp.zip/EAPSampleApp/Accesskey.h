//
//  Accesskey.h
//  Accesskey
//
//

#ifndef Accesskey_h
#define Accesskey_h


#define ACCESSKEY @"lmt1c0vtpq65f5b97q13d4k9bt9bq3"

#endif /* Accesskey_h */
