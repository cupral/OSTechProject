//
//  ExtraUITextField.h
//  EAPSampleApp
//
//  Created by user on 2018/02/09.
//  Copyright © 2018年 HiICS. All rights reserved.
//

#ifndef ExtraUITextField_h
#define ExtraUITextField_h

#import <UIKit/UIKit.h>

@interface ExtraUITextField : UITextField

@end

#endif /* ExtraUITextField_h */
