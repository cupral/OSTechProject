//
//  MainTabController.h
//  EAPSampleApp
//
//  Created by user on 2018/02/02.
//  Copyright © 2018年 HiICS. All rights reserved.
//

#ifndef MainTabController_h
#define MainTabController_h

#import <UIKit/UIKit.h>


@interface MainTabBarController : UITabBarController
@end

#endif /* MainTabController_h */
