<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
    <context>
        <name>behavior_1/behavior.xar:/Animated Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Animated Say/Animated Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Animated Say/n_両手でバイバイ/behavior_layer1/keyframe60/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Caption/App end</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>頭に触ると、アプリが終了するよ？</source>
            <comment>Text</comment>
            <translation type="unfinished">頭に触ると、アプリが終了するよ？</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Caption/Good job</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>よくできましたぁ。</source>
            <comment>Text</comment>
            <translation type="unfinished">よくできましたぁ。</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Caption/Hi</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>あ、どうも。ペッパーです。</source>
            <comment>Text</comment>
            <translation type="unfinished">あ、どうも。ペッパーです。</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Caption/Installed</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>ボクが今しゃべっているということは、ちゃんとインストールできタんだね？</source>
            <comment>Text</comment>
            <translation type="unfinished">ボクが今しゃべっているということは、ちゃんとインストールできタんだね？</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Caption/Uninstall</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>アプリが終了し鱈、アンインストールしてね？</source>
            <comment>Text</comment>
            <translation type="unfinished">アプリが終了し鱈、アンインストールしてね？</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Caption/n_両手でバイバイ/behavior_layer1/keyframe60/Say</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>じゃ、ばいばーーい？</source>
            <comment>Text</comment>
            <translation type="unfinished">じゃ、ばいばーーい？</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Stand Init/speak/keyframe25/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>終了します</source>
            <comment>Text</comment>
            <translation type="unfinished">終了します</translation>
        </message>
    </context>
</TS>
