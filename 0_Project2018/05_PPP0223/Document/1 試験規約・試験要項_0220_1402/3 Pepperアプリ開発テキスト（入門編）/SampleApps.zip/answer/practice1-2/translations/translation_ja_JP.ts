<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ja_JP">
    <context>
        <name>behavior_1/behavior.xar:/Caption/App end</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>頭に触ると、アプリが終了するよ？</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Caption/Good job</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>よくできましたぁ。</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Caption/Hi</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>あ、どうも。ペッパーです。</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Caption/Installed</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>ボクが今しゃべっているということは、ちゃんとインストールできタんだね？</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Caption/Uninstall</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>アプリが終了し鱈、アンインストールしてね？</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Caption/n_両手でバイバイ/behavior_layer1/keyframe60/Say</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>じゃ、ばいばーーい？</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Stand Init/speak/keyframe25/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">こんにちは</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>終了します</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
</TS>
