<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
    <context>
        <name>3-2-1/behavior.xar:/No</name>
        <message>
            <location filename="3-2-1/behavior.xar" line="0"/>
            <source>\rspd=110\\vct=135\日本人なら、一度は登ってみたいですよね？\rspd=100\\vct=125\たぶん、\pau=500\\rspd=110\ボクわぁ、無理だと思うんだ？</source>
            <comment>Text</comment>
            <translation type="unfinished">\rspd=110\\vct=135\日本人なら、一度は登ってみたいですよね？\rspd=100\\vct=125\たぶん、\pau=500\\rspd=110\ボクわぁ、無理だと思うんだ？</translation>
        </message>
    </context>
    <context>
        <name>3-2-1/behavior.xar:/Please again</name>
        <message>
            <location filename="3-2-1/behavior.xar" line="0"/>
            <source>ごめんなさい。もう一度言ってもらえますか？</source>
            <comment>Text</comment>
            <translation type="unfinished">ごめんなさい。もう一度言ってもらえますか？</translation>
        </message>
    </context>
    <context>
        <name>3-2-1/behavior.xar:/Question</name>
        <message>
            <location filename="3-2-1/behavior.xar" line="0"/>
            <source>突然ですが、富士山に登ったことありますか？</source>
            <comment>Text</comment>
            <translation type="unfinished">突然ですが、富士山に登ったことありますか？</translation>
        </message>
    </context>
    <context>
        <name>3-2-1/behavior.xar:/Yes</name>
        <message>
            <location filename="3-2-1/behavior.xar" line="0"/>
            <source>\rspd=110\\vct=165\スゴぉーーいっ？\vct=145\ボクなんか、1.5センチしか登れないのにっ！</source>
            <comment>Text</comment>
            <translation type="unfinished">\rspd=110\\vct=165\スゴぉーーいっ？\vct=145\ボクなんか、1.5センチしか登れないのにっ！</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Animated Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/No</name>
        <message>
            <source>\rspd=110\\vct=135\日本人なら、一度は登ってみたいですよね？\rspd=100\\vct=125\たぶん、\pau=500\\rspd=110\ボクわぁ、無理だと思うんだ？</source>
            <comment>Text</comment>
            <translation type="obsolete">\rspd=110\\vct=135\日本人なら、一度は登ってみたいですよね？\rspd=100\\vct=125\たぶん、\pau=500\\rspd=110\ボクわぁ、無理だと思うんだ？</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Please again</name>
        <message>
            <source>ごめんなさい。もう一度言ってもらえますか？</source>
            <comment>Text</comment>
            <translation type="obsolete">ごめんなさい。もう一度言ってもらえますか？</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Question</name>
        <message>
            <source>突然ですが、富士山に登ったことありますか？</source>
            <comment>Text</comment>
            <translation type="obsolete">突然ですが、富士山に登ったことありますか？</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>こんにちは</source>
            <comment>Text</comment>
            <translation type="obsolete">こんにちは</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Yes</name>
        <message>
            <source>\rspd=110\\vct=165\スゴぉーーいっ？\vct=145\ボクなんか、1.5センチしか登れないのにっ！</source>
            <comment>Text</comment>
            <translation type="obsolete">\rspd=110\\vct=165\スゴぉーーいっ？\vct=145\ボクなんか、1.5センチしか登れないのにっ！</translation>
        </message>
    </context>
</TS>
