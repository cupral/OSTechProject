<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ja_JP">
    <context>
        <name>behavior_1/behavior.xar:/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">こんにちは</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>おシマぁぁい！</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say A button</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>エーボタンが押されました。</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say B button</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>ビーボタンが押されました。</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Timeline/behavior_layer1/keyframe57/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">こんにちは</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>A、B、どちらかのボタンを押してください。</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
</TS>
