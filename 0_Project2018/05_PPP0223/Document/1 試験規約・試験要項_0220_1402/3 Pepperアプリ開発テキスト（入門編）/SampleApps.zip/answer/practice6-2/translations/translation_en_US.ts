<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
    <context>
        <name>behavior_1/behavior.xar:/Hand up/behavior_layer1/keyframe75/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>どちらかの手の甲に触ってください。</source>
            <comment>Text</comment>
            <translation type="unfinished">どちらかの手の甲に触ってください。</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Left</name>
        <message>
            <source>右手が触られました。</source>
            <comment>Text</comment>
            <translation type="obsolete">右手が触られました。</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>左手が触られました。</source>
            <comment>Text</comment>
            <translation type="unfinished">左手が触られました。</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Right</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>右手が触られました。</source>
            <comment>Text</comment>
            <translation type="unfinished">右手が触られました。</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>おシマぁぁい！</source>
            <comment>Text</comment>
            <translation type="unfinished">おシマぁぁい！</translation>
        </message>
    </context>
</TS>
