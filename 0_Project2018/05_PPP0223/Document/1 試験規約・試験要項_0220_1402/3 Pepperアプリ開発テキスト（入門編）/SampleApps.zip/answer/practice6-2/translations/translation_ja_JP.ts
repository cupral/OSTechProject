<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ja_JP">
    <context>
        <name>behavior_1/behavior.xar:/Hand up/behavior_layer1/keyframe75/Say</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>どちらかの手の甲に触ってください。</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Left</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>左手が触られました。</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Right</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>右手が触られました。</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>おシマぁぁい！</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
</TS>
