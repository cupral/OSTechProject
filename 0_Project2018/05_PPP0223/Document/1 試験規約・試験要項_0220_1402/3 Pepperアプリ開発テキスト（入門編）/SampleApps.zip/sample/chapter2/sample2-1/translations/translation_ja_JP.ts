<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ja_JP">
    <context>
        <name>behavior_1/behavior.xar:/Main/Fight/behavior_layer1/keyframe25/Fight</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>期待してるから、がんばってくださいねぇ？</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Main/Fight/behavior_layer1/keyframe25/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">こんにちは</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Main/I am Pepper/behavior_layer1/keyframe75/I am Pepper</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>\rspd=110\\vct=125\みなさん\rspd=110\\vct=135\こんにちは！！\rspd=120\\vct=135\ペッパーです！</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Main/I am Pepper/behavior_layer1/keyframe75/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">こんにちは</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Main/MyApp Create/behavior_layer1/keyframe50/MyApp Create</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>これから、僕のアプリを、作ってくれるんでしょ？</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
</TS>
