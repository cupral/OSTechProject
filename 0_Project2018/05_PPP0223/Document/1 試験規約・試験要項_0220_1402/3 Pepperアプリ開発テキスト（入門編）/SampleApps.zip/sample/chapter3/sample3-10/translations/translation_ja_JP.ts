<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ja_JP">
    <context>
        <name>behavior_1/behavior.xar:/Animated Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">こんにちは</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/I don't like animal</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>\pau=1000\もう少し空気読んで下さい世ぉ！</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/I like cats</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>\pau=1000\実は2匹飼っています</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/I like dog</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>\pau=1000\いつか飼ってみたいです</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Timeout</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>\pau=1000\おわっちゃうよぉぉっ？</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
</TS>
