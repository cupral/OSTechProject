<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ja_JP">
    <context>
        <name>behavior_1/behavior.xar:/Animated Say</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>こんにちは、僕はペッパーです。\pau=1000\アニメイテッドセイボックスは、喋りながら自動的に動きが付きます。</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
</TS>
