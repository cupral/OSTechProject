<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ja_JP">
    <context>
        <name>behavior_1/behavior.xar:/Bye</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>さようなら</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Hello</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>こんにちは</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Please again</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>もう一度お願いします</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
</TS>
