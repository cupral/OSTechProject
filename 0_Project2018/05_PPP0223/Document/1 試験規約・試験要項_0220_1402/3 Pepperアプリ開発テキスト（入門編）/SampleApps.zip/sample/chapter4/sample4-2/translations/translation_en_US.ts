<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
    <context>
        <name>behavior_1/behavior.xar:/Timeline/speak/keyframe1/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>\vct=110\\vol=40\前にぃぃぃ？\vct=145\\vol=100\なラエっ！</source>
            <comment>Text</comment>
            <translation type="unfinished">\vct=110\\vol=40\前にぃぃぃ？\vct=145\\vol=100\なラエっ！</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Timeline/speak/keyframe75/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>\vct=150\きょぅつケっ！\vct=135\</source>
            <comment>Text</comment>
            <translation type="unfinished">\vct=150\きょぅつケっ！\vct=135\</translation>
        </message>
    </context>
</TS>
