<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ja_JP">
    <context>
        <name>behavior_1/behavior.xar:/Timeline/speak/keyframe1/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">こんにちは</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>\vct=110\\vol=40\前にぃぃぃ？\vct=145\\vol=100\なラエっ！</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Timeline/speak/keyframe75/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">こんにちは</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>\vct=150\きょぅつケっ！\vct=135\</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
</TS>
