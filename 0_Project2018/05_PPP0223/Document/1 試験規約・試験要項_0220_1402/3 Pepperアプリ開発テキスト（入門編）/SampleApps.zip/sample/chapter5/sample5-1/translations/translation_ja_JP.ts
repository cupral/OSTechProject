<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ja_JP">
    <context>
        <name>behavior_1/behavior.xar:/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">こんにちは</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/s_ぎ</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>ぎ</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/s_ひだ</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>ひだ</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/s_み</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>み</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/s_り</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>り</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
</TS>
