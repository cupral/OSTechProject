<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ja_JP">
    <context>
        <name>interactive/behavior.xar:/Animated Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">こんにちは</translation>
        </message>
        <message>
            <location filename="interactive/behavior.xar" line="0"/>
            <source>\rspd=90\ほぉーラっ？、\rspd=110\サンプル、7の2のインタラクティブアクティビティーが起動したよぉ？</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
    <context>
        <name>solitary/behavior.xar:/Animated Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">こんにちは</translation>
        </message>
        <message>
            <location filename="solitary/behavior.xar" line="0"/>
            <source>サンプル、7の2のソリタリーアクティビティーが、起動したよぉ？\pau=1000\近づくと、インタラクティブアクティビティーが起動するよー？</source>
            <comment>Text</comment>
            <translation type="unfinished"></translation>
        </message>
    </context>
</TS>
